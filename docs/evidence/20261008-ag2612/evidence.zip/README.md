# ag2612 SimNow 仿真验收证据包

实际交易日期：北京时间 2026-10-08 夜盘；交易日 20261009。整理日期：2026-10-09。

本地新增验收工具已完成一次 1 手买开和卖出平今，最终两轮完整服务器查询均为总持仓 0、活动委托 0。独立安装版 VeighNa 客户端通过另一条行情连接，与采集器 361 条同期 Tick 的六字段全部一致。全部 9 项离线证据复核通过。

## 先看结果

- [详细报告](wiki/sources/SimNow完整仿真验收记录-2026-10-08.md)
- [工具设计、测试和边界](wiki/code/SimNow开平仓与独立客户端验收设计.md)
- [机器可读复核与逐条行情对照](data/simnow_checks/20261008-ag2612-acceptance-evidence/validation.json)
- [独立客户端截图](data/simnow_checks/20261008-235327-acceptance-d71dc1/client.png)

买开成交：23:52:45，1 手，14338；卖平今成交：23:52:49，1 手，14336。结果只证明这次仿真工程闭环，不是收益评估或原突破策略已通过验收。

## 离线复核（不登录、不下单）

解压后在本文件所在目录使用 Python 执行下面一行；复核器只依赖标准库：

```text
python -B scripts/simnow/verify_acceptance.py --trade data/simnow_checks/20261008-235242-acceptance-67c370 --reference data/simnow_checks/20261008-235327-acceptance-d71dc1 --capture data/simnow_checks/20261008-235417-e7e9f4 --capture data/simnow_checks/20261008-235715-b50c3a --output recheck
```

期望输出 passed=true，9 项 checks 为 true；两个窗口分别 181 和 180 条匹配，differences=0、unmatched=0。原验证结果中的 artifacts 路径相对原工作区根目录，本包保持相同结构。SHA256SUMS.txt 可核对打包文件完整性。

13 项交易护栏/回调测试和 4 项对照器测试已在本机通过。复跑命令分别是 `python -B scripts/simnow/test_acceptance.py`、`python -B scripts/simnow/test_verify_acceptance.py`；前者导入已安装的 vnpy_ctp（本次 6.7.11.3），不会初始化 API 或联网。

## 证据边界

- 同期数值对照来自两个独立进程、连接和行情处理实现，但共享 SimNow 上游与 CTP 库，不是不同数据商的交叉验证。
- 截图用于证明客户端展示，拍摄时间晚于两段正式对照窗口。客户端仅连接行情，空的委托/持仓面板不是空仓证据；空仓结论来自交易服务器完整查询。
- GUI 在 STOP 后未正常退出，最后核实身份后终止只读进程；finalization.json 记录这一已知收尾缺陷。交易程序正常退出。全部本次进程已停止。
- 本包排除加密凭据、原生 API 二进制 flow 和账户资金；没有修改原始成交和行情数字。脚本含通用凭据字段名称，不含用户配置。
- 本地工具尚未同步公开仓库；原突破策略整改、因子研究及冻结后前测仍需单独完成。WIKI 中 [[双向链接]] 指向原知识库，包内详细原始证据链接可直接使用；报告中指向本 ZIP 的链接仅在原工作区有效。

不要为了复核本次证据重新运行带 `-ExecuteSimNow` 的入口；它会在仿真账户发起新一轮订单。默认入口也会连接和确认仿真结算，离线审阅请用上述 verify_acceptance.py。
