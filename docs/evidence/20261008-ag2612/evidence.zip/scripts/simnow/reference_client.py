"""VeighNa's installed standard GUI and CTP gateway, separate read-only MD connection."""
import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
from datetime import datetime, timedelta, timezone
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--output', required=True)
parser.add_argument('--contract', required=True)
args = parser.parse_args()
output = Path(args.output).resolve()
contract_info = json.loads(Path(args.contract).read_text(encoding='utf-8'))
output.mkdir(parents=True, exist_ok=True)
(output / '.vntrader').mkdir(exist_ok=True)
os.chdir(output)
user, password = os.environ.pop('SIMNOW_USERID'), os.environ.pop('SIMNOW_PASSWORD')

from vnpy.event import EventEngine
from vnpy.trader.engine import MainEngine
from vnpy.trader.ui import MainWindow, create_qapp
from vnpy.trader.ui.qt import QtCore
from vnpy.trader.constant import Exchange, Product
from vnpy.trader.object import ContractData, SubscribeRequest
from vnpy.trader.event import EVENT_TICK
from vnpy_ctp import CtpGateway
from vnpy_ctp.gateway.ctp_gateway import symbol_contract_map
import vnpy_ctp.gateway.ctp_gateway as gateway_module

app = create_qapp('SimNow read-only reference')
engine = EventEngine()
main = MainEngine(engine)
gateway = main.add_gateway(CtpGateway)
def deny_orders(*args, **kwargs):
    raise RuntimeError('Read-only reference client cannot send or cancel orders')
gateway.send_order = deny_orders
gateway.cancel_order = deny_orders
window = MainWindow(main, engine)
window.setWindowTitle('VeighNa Trader - SimNow ag2612 READ ONLY reference')
window.trading_widget.setEnabled(False)
window.menuBar().setEnabled(False)
window.resize(1480, 920)
window.show()
contract = ContractData(symbol='ag2612', exchange=Exchange.SHFE, name='白银2612',
                        product=Product.FUTURES, size=contract_info['VolumeMultiple'],
                        pricetick=contract_info['PriceTick'], gateway_name='CTP')
symbol_contract_map['ag2612'] = contract
gateway.on_contract(contract)
tz = timezone(timedelta(hours=8))
ticks = (output / 'reference_ticks.jsonl').open('a', encoding='utf-8')
state = {'client': 'Installed VeighNa MainWindow + CtpGateway.CtpMdApi', 'separate_process': True,
         'separate_connection': True, 'same_upstream': 'SimNow 182.254.243.31:30011',
         'sends_orders': False, 'tick_count': 0, 'started_at': datetime.now(tz).isoformat(),
         'vnpy_version': importlib.metadata.version('vnpy'), 'ctp_version': importlib.metadata.version('vnpy_ctp'),
         'gateway_source_sha256': hashlib.sha256(Path(gateway_module.__file__).read_bytes()).hexdigest()}
def on_tick(event):
    t = event.data
    if t.symbol != 'ag2612': return
    row = {'received_at': datetime.now(tz).isoformat(timespec='milliseconds'), 'symbol': t.symbol,
           'market_at': t.datetime.isoformat(timespec='milliseconds'), 'last': t.last_price,
           'bid': t.bid_price_1, 'ask': t.ask_price_1, 'volume': t.volume,
           'bid_volume': t.bid_volume_1, 'ask_volume': t.ask_volume_1}
    ticks.write(json.dumps(row) + '\n'); ticks.flush()
    state['tick_count'] += 1
    state['latest_tick'] = row
engine.register(EVENT_TICK, on_tick)
def heartbeat():
    (output / 'reference_summary.json').write_text(json.dumps(state, indent=2), encoding='utf-8')
    if (output / 'STOP').exists(): app.quit()
timer = QtCore.QTimer()
timer.timeout.connect(heartbeat)
timer.start(1000)
QtCore.QTimer.singleShot(900000, app.quit)
gateway.md_api.connect('tcp://182.254.243.31:30011', user, password, '9999', True)
gateway.subscribe(SubscribeRequest(symbol='ag2612', exchange=Exchange.SHFE))
app.exec()
main.close()
ticks.close()
state['finished'] = True
state['ended_at'] = datetime.now(tz).isoformat()
(output / 'reference_summary.json').write_text(json.dumps(state, indent=2), encoding='utf-8')
