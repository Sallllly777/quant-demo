"""Build an allowlisted offline evidence bundle; never reads encrypted credentials."""
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / 'data/simnow_checks'
OUT = DATA / '20261008-ag2612-acceptance-evidence'
BUNDLE = OUT / 'bundle'
TRADE = '20261008-235242-acceptance-67c370'
REFERENCE = '20261008-235327-acceptance-d71dc1'
CAPTURES = ['20261008-235417-e7e9f4', '20261008-235715-b50c3a']

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def copy(path):
    relative = path.relative_to(ROOT)
    target = BUNDLE / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, target)

validation = json.loads((OUT/'validation.json').read_text(encoding='utf-8'))
assert validation['passed'] and all(validation['checks'].values())
manifest = json.loads((DATA/TRADE/'manifest.json').read_text(encoding='utf-8'))
assert manifest['source_sha256'] == digest(ROOT/'scripts/simnow/acceptance.py'), 'Execution source has changed'
BUNDLE.mkdir(parents=True, exist_ok=True)
for name in ['acceptance.py','capture.py','analyze.py','reference_client.py','verify_acceptance.py',
             'test_acceptance.py','test_capture.py','test_verify_acceptance.py',
             'start.ps1','start_acceptance.ps1','configure.ps1','build_acceptance_bundle.py']:
    copy(ROOT/'scripts/simnow'/name)
for name in ['manifest.json','events.jsonl','summary.json','contract.json','initial.json',
             'after_open.json','final.json','final_repeat.json','own_trades.json','close_check_0.json','close_check_1.json']:
    copy(DATA/TRADE/name)
for name in ['reference_ticks.jsonl','reference_summary.json','client.png','client_accessibility.txt','finalization.json']:
    copy(DATA/REFERENCE/name)
for run in CAPTURES:
    for name in ['manifest.json','events.jsonl','summary.json','ticks.csv']:
        copy(DATA/run/name)
copy(OUT/'validation.json')
for path in ['wiki/sources/SimNow完整仿真验收记录-2026-10-08.md','wiki/code/SimNow开平仓与独立客户端验收设计.md']:
    copy(ROOT/path)

readme = '''# ag2612 SimNow 仿真验收证据包

实际交易日期：北京时间 2026-10-08 夜盘；交易日 20261009。整理日期：2026-10-09。

本地新增验收工具已完成一次 1 手买开和卖出平今，最终两轮完整服务器查询均为总持仓 0、活动委托 0。独立安装版 VeighNa 客户端通过另一条行情连接，与采集器 361 条同期 Tick 的六字段全部一致。全部 9 项离线证据复核通过。

## 先看结果

- [详细报告](wiki/sources/SimNow完整仿真验收记录-2026-10-08.md)
- [工具设计、测试和边界](wiki/code/SimNow开平仓与独立客户端验收设计.md)
- [机器可读复核与逐条行情对照](data/simnow_checks/20261008-ag2612-acceptance-evidence/validation.json)
- [独立客户端截图](data/simnow_checks/20261008-235327-acceptance-d71dc1/client.png)

买开成交：23:52:45，1 手，14338；卖平今成交：23:52:49，1 手，14336。结果只证明这次仿真工程闭环，不是收益评估或原突破策略已通过验收。

## 离线复核（不登录、不下单）

解压后在本文件所在目录使用 Python 执行下面一行；复核器只依赖标准库：

```text
python -B scripts/simnow/verify_acceptance.py --trade data/simnow_checks/20261008-235242-acceptance-67c370 --reference data/simnow_checks/20261008-235327-acceptance-d71dc1 --capture data/simnow_checks/20261008-235417-e7e9f4 --capture data/simnow_checks/20261008-235715-b50c3a --output recheck
```

期望输出 passed=true，9 项 checks 为 true；两个窗口分别 181 和 180 条匹配，differences=0、unmatched=0。原验证结果中的 artifacts 路径相对原工作区根目录，本包保持相同结构。SHA256SUMS.txt 可核对打包文件完整性。

13 项交易护栏/回调测试和 4 项对照器测试已在本机通过。复跑命令分别是 `python -B scripts/simnow/test_acceptance.py`、`python -B scripts/simnow/test_verify_acceptance.py`；前者导入已安装的 vnpy_ctp（本次 6.7.11.3），不会初始化 API 或联网。

## 证据边界

- 同期数值对照来自两个独立进程、连接和行情处理实现，但共享 SimNow 上游与 CTP 库，不是不同数据商的交叉验证。
- 截图用于证明客户端展示，拍摄时间晚于两段正式对照窗口。客户端仅连接行情，空的委托/持仓面板不是空仓证据；空仓结论来自交易服务器完整查询。
- GUI 在 STOP 后未正常退出，最后核实身份后终止只读进程；finalization.json 记录这一已知收尾缺陷。交易程序正常退出。全部本次进程已停止。
- 本包排除加密凭据、原生 API 二进制 flow 和账户资金；没有修改原始成交和行情数字。脚本含通用凭据字段名称，不含用户配置。
- 本地工具尚未同步公开仓库；原突破策略整改、因子研究及冻结后前测仍需单独完成。WIKI 中 [[双向链接]] 指向原知识库，包内详细原始证据链接可直接使用；报告中指向本 ZIP 的链接仅在原工作区有效。

不要为了复核本次证据重新运行带 `-ExecuteSimNow` 的入口；它会在仿真账户发起新一轮订单。默认入口也会连接和确认仿真结算，离线审阅请用上述 verify_acceptance.py。
'''
(BUNDLE/'README.md').write_text(readme,encoding='utf-8')

# Fail if credential-bearing response keys accidentally entered selected runtime JSON.
for path in (BUNDLE/'data').rglob('*'):
    if path.suffix not in {'.json','.jsonl'}: continue
    content=path.read_text(encoding='utf-8-sig')
    for key in ('UserID','InvestorID','Password','AccountID','AuthCode'):
        assert '"'+key+'"' not in content, f'Unexpected private response field in {path.name}'

files=sorted(p for p in BUNDLE.rglob('*') if p.is_file() and p.name!='SHA256SUMS.txt')
(BUNDLE/'SHA256SUMS.txt').write_text(''.join(f'{digest(p)}  {p.relative_to(BUNDLE).as_posix()}\n' for p in files),encoding='utf-8')
zip_path=DATA/'ag2612-acceptance-20261008.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for path in sorted(BUNDLE.rglob('*')):
        if path.is_file(): z.write(path,path.relative_to(BUNDLE).as_posix())
with zipfile.ZipFile(zip_path) as z:
    assert z.testzip() is None
    assert all('.simnow_private' not in n and '_flow/' not in n for n in z.namelist())
print(json.dumps({'zip':str(zip_path),'bytes':zip_path.stat().st_size,'sha256':digest(zip_path),'files':len(files)+1},ensure_ascii=False))
